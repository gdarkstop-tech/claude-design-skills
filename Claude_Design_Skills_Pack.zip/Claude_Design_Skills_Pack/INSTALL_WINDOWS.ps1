$ErrorActionPreference = "Stop"

Write-Host "Claude Design Skills Pack - Windows" -ForegroundColor Cyan

if (-not (Get-Command npx -ErrorAction SilentlyContinue)) {
    throw "npx was not found. Install Node.js first, then run this script again."
}

Write-Host "[1/3] Installing Emil Design Engineering..."
npx skills add https://github.com/emilkowalski/skills --skill emil-design-eng -g -a claude-code -y --copy

Write-Host "[2/3] Installing Impeccable..."
npx impeccable install --providers=claude --scope=global

Write-Host "[3/3] Installing Taste Skill..."
npx skills add https://github.com/Leonxlnx/taste-skill --skill design-taste-frontend -g -a claude-code -y --copy

Write-Host "Done. Restart Claude Code." -ForegroundColor Green
Write-Host "Then run /impeccable init inside Claude Code."
