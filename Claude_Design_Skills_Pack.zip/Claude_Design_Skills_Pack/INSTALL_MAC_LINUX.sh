#!/usr/bin/env bash
set -euo pipefail

if ! command -v npx >/dev/null 2>&1; then
  echo "npx was not found. Install Node.js first."
  exit 1
fi

echo "[1/3] Installing Emil Design Engineering..."
npx skills add https://github.com/emilkowalski/skills --skill emil-design-eng -g -a claude-code -y --copy

echo "[2/3] Installing Impeccable..."
npx impeccable install --providers=claude --scope=global

echo "[3/3] Installing Taste Skill..."
npx skills add https://github.com/Leonxlnx/taste-skill --skill design-taste-frontend -g -a claude-code -y --copy

echo "Done. Restart Claude Code, then run /impeccable init."
