# Claude Design Skills Pack

ده الباك الخاص بالـ 3 Skills الظاهرين في الريل:

1. **Emil Design Engineering** — `emil-design-eng`
   - تحسين الـ UI polish، الحركة، easing، micro-interactions، والـ details الصغيرة.
   - المصدر: `emilkowalski/skills`

2. **Impeccable**
   - Audit + polish + critique للواجهات، وإصلاح مشاكل spacing / hierarchy / typography / states قبل الـ shipping.
   - المصدر: `pbakaus/impeccable`

3. **Taste Skill** — `design-taste-frontend`
   - يمنع شكل الـ AI generic، ويقوّي الـ visual direction، typography، layout، motion، density والـ premium feel.
   - المصدر: `Leonxlnx/taste-skill`

## التثبيت على Claude Code

> لازم Node.js / npx يكونوا موجودين، ويفضل تشغيل الأوامر من Terminal.

### 1) Emil Design Engineering
```bash
npx skills add https://github.com/emilkowalski/skills --skill emil-design-eng -g -a claude-code -y --copy
```

### 2) Impeccable
```bash
npx impeccable install --providers=claude --scope=global
```

بعد التثبيت داخل Claude Code شغّل:
```text
/impeccable init
```

### 3) Taste Skill
```bash
npx skills add https://github.com/Leonxlnx/taste-skill --skill design-taste-frontend -g -a claude-code -y --copy
```

بعدها اقفل Claude Code وافتحه تاني.

## اختبار سريع

- Emil:
  `Use emil-design-eng to review this interface for motion, interaction and UI polish. Fix the issues directly.`

- Impeccable:
  `/impeccable audit`
  ثم:
  `/impeccable polish`

- Taste Skill:
  `Use design-taste-frontend to redesign this interface so it feels premium, intentional and non-generic. Keep functionality unchanged.`

## Figma — اختياري لكنه موجود في نفس workflow بتاع الريل

الطريقة المفضلة حاليًا مع Claude Code:
```bash
claude plugin install figma@claude-plugins-official
```

بعدها Restart لـ Claude Code، وافتح `/plugin` واعمل Authenticate لـ Figma.

بديل يدوي:
```bash
claude mcp add --scope user --transport http figma https://mcp.figma.com/mcp
```

ثم افتح Claude Code واستخدم `/mcp` للتأكد إن Figma connected.

## ملاحظة
الـ Skills الثلاثة مش بدائل لبعض؛ الأفضل تستخدمهم مع بعض:
- Taste = direction / taste
- Emil = motion + interaction polish
- Impeccable = audit + final cleanup
